//
//  UpdateViewController.swift
//  SQLite_Demo3
//
//  Created by Shubham Shinde on 20/01/21.
//

import UIKit

class UpdateViewController: UIViewController {

    @IBOutlet weak var updateName: UITextField!
    @IBOutlet weak var updateLastName: UITextField!
    
    var name = String()
    var lastName = String()
    
    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var lastNameLable: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        updateName.text = name
        updateLastName.text = lastName
        
    }
    @IBAction func actionButton(_ sender: UIButton) {
        
        let nameArray = DBWrapper.sharedObject.taskNameArray
        let lastNameArray = DBWrapper.sharedObject.taskLastNameArray
        var total = 0
        var total2 = 0
        for i in nameArray {
            for j in lastNameArray {
                let selectQuery = "select taskName, taskLastName from taskTable"
                DBWrapper.sharedObject.selectAllTask(query: selectQuery)
                nameLable.text = nameArray[0]
                lastNameLable.text = lastNameArray[0]
                total += 1
                total2 += 2
                print(i)
                print(j)
            }
        }
       
    }
    
    @IBAction func updateButton(_ sender: Any) {
        let updateQuery = "update taskTable set taskLastName = '\(updateLastName.text!)' where taskName = '\(updateName.text!)'"
        let isSuccess = DBWrapper.sharedObject.executeQuery(query: updateQuery)
        if isSuccess {
            print("update: Success")
            print(name)
            print(lastName)
        } else {
            print("update: Failed")
        }
    }
    
   
    @IBAction func deleteButton(_ sender: Any) {
        let deleteQuery = "delete from taskTable where taskName = '\(updateName.text!)'"
        let isSuccess = DBWrapper.sharedObject.executeQuery(query: deleteQuery)
        if isSuccess {
            print("delete: Success")
        } else {
            print("delete: Failed")
        }
    }
    
}
