//
//  InsertViewController.swift
//  SQLite_Demo3
//
//  Created by Shubham Shinde on 20/01/21.
//

import UIKit


class InsertViewController: UIViewController{
   
    
    
    @IBOutlet weak var textName: UITextField!
    @IBOutlet weak var textLastName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    @IBAction func insertButton(_ sender: Any) {
        let insertQuery = "insert into taskTable(taskName,taskLastName) values ('\(textName.text!)','\(textLastName.text!)')"
        let isSusccess = DBWrapper.sharedObject.executeQuery(query: insertQuery)
        if isSusccess {
            print("insert: Success")
            navigationController?.popViewController(animated: true)
        } else {
            print("insert: Failed")
        }
    }

    
}
