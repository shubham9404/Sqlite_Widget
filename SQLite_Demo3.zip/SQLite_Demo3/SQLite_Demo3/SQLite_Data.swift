//
//  SQLite_Data.swift
//  SQLite_Demo3
//
//  Created by Shubham Shinde on 20/01/21.
//

import Foundation

struct Personal {
    let result: [PersonalData]
}

struct PersonalData {
    var tNameArray : [String] = []
    var tLastNameArray : [String] = []
}


