//
//  ViewController.swift
//  SQLite_Demo3
//
//  Created by Shubham Shinde on 20/01/21.
//

import UIKit


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var data = PersonalData()
    
    @IBOutlet weak var viewTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print(data.tNameArray)
        print(data.tLastNameArray)
    }

    @IBAction func actionButton(_ sender: Any) {
        let insertPage = storyboard?.instantiateViewController(withIdentifier: "InsertViewController") as! InsertViewController
        navigationController?.pushViewController(insertPage, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.tNameArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        cell.detailTextLabel?.text = data.tNameArray[indexPath.row]
        cell.textLabel?.text = data.tLastNameArray[indexPath.row]
        return cell
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let selectQuery = "select taskName, taskLastName from taskTable"
        DBWrapper.sharedObject.selectAllTask(query: selectQuery)
        data.tNameArray = DBWrapper.sharedObject.taskNameArray
        data.tLastNameArray = DBWrapper.sharedObject.taskLastNameArray
        viewTableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = viewTableView.cellForRow(at: indexPath)!
        let editPage = storyboard?.instantiateViewController(withIdentifier: "UpdateViewController") as! UpdateViewController
        editPage.lastName = (cell.detailTextLabel?.text)!
        editPage.name = (cell.textLabel?.text)!
        navigationController?.pushViewController(editPage, animated: true)
    }
}

