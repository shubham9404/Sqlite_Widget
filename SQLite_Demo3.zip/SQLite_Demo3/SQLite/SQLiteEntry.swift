//
//  SQLiteEntry.swift
//  SQLite_Demo3
//
//  Created by Shubham Shinde on 21/01/21.
//

import WidgetKit
import SQLite3

struct SQLiteEntry: TimelineEntry {
    let date: Date
    let configuration: ConfigurationIntent
    let name: String
    let lastName: String

    
    
    static func mockEntry() -> SQLiteEntry {
        return SQLiteEntry(date: Date(), configuration: ConfigurationIntent(),name: "String", lastName: "String")
        
    }
}

func getData() -> ([String]) {
    let databaseName: [String]
    let databaseLastName: [String]
    let selectQuery = "select taskName, taskLastName from taskTable"
    DBWrapper.sharedObject.selectAllTask(query: selectQuery)
    databaseName = DBWrapper.sharedObject.taskNameArray
    databaseLastName = DBWrapper.sharedObject.taskLastNameArray
    print(DBWrapper.sharedObject.taskNameArray, DBWrapper.sharedObject.taskLastNameArray)
    let newArray = databaseName + databaseLastName
    return newArray
}

