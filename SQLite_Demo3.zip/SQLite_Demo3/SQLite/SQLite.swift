//
//  SQLite.swift
//  SQLite
//
//  Created by Shubham Shinde on 21/01/21.
//

import WidgetKit
import SwiftUI
import Intents

struct SQLiteEntryView : View {
    var entry: Provider.Entry



    @Environment(\.widgetFamily) var family
    
    var body: some View {
        VStack {
            Text(entry.name)
            Text(entry.lastName)
        }
    }
}

@main
struct SQLite: Widget {
    let kind: String = "SQLite"

    var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: ConfigurationIntent.self, provider: Provider()) { entry in
            SQLiteEntryView(entry: entry)
        }
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
    }
}

struct SQLite_Previews: PreviewProvider {
    static var previews: some View {
        SQLiteEntryView(entry: SQLiteEntry(date: Date(), configuration: ConfigurationIntent(), name: "String", lastName: "String"))
            .previewContext(WidgetPreviewContext(family: .systemSmall))
    }
}
