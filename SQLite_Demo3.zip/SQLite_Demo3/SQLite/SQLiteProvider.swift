//
//  SQLiteProvider.swift
//  SQLite_Demo3
//
//  Created by Shubham Shinde on 21/01/21.
//

import WidgetKit


struct Provider: IntentTimelineProvider {
    typealias Entry = SQLiteEntry
    
    func placeholder(in context: Context) -> SQLiteEntry {
        SQLiteEntry.init(date: Date(), configuration: ConfigurationIntent(), name: "String", lastName: "String")
        
    }

    func getSnapshot(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (SQLiteEntry) -> ()) {
        let entry = SQLiteEntry.init(date: Date(), configuration: ConfigurationIntent(), name: "String", lastName: "String")
        completion(entry)
    }

    func getTimeline(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
        
        var entries: [SQLiteEntry] = []
        print("String")
        // Generate a timeline consisting of five entries an hour apart, starting from the current date.
        let array = PersonalData()
        var total:Int = 0
        var total2:Int = 0
        print(array.tNameArray.count)
        print(array.tLastNameArray.count)
        let currentDate = Date()
        for hourOffset in 0 ..< 5 {
            let entryDate = Calendar.current.date(byAdding: .second, value: hourOffset * 2, to: currentDate)!
            let entry = SQLiteEntry(date: entryDate, configuration: configuration, name: array.tNameArray[total], lastName: array.tLastNameArray[total2])
            entries.append(entry)
            total += 1
            total2 += 1
        }

        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
    }
}
