//
//  LargeView.swift
//  SQLite_Demo3
//
//  Created by Shubham Shinde on 21/01/21.
//

import SwiftUI

struct LargeView: View {
    
    private var sqlite: PersonalData
    
    init(sqlite: PersonalData) {
        self.sqlite = sqlite
    }
    
    var body: some View {
        VStack(alignment:.leading, spacing:10){

            Text("Upcoming trips")
                .font(Font.headline)
                .foregroundColor(Color.primary)

            Text(sqlite.tNameArray[0]).font(.subheadline)
                .foregroundColor(Color.secondary)
            
            Text(sqlite.tLastNameArray[0]).font(.title)
        }
    }
}

struct LargeView_Previews: PreviewProvider {
    static var previews: some View {
        LargeView(sqlite: PersonalData())
    }
}
